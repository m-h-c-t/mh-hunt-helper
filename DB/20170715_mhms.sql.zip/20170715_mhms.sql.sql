-- --------------------------------------------------------
-- Host:                         localhost
-- Server version:               5.7.17-0ubuntu0.16.04.2 - (Ubuntu)
-- Server OS:                    Linux
-- HeidiSQL Version:             9.4.0.5174
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


-- Dumping database structure for mhmapspotter
CREATE DATABASE IF NOT EXISTS `mhmapspotter` /*!40100 DEFAULT CHARACTER SET utf16 */;
USE `mhmapspotter`;

-- Dumping structure for table mhmapspotter.fb_groups
CREATE TABLE IF NOT EXISTS `fb_groups` (
  `id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `fb_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `fb_id` (`fb_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf16;

-- Data exporting was unselected.
-- Dumping structure for table mhmapspotter.fb_users
CREATE TABLE IF NOT EXISTS `fb_users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `fb_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `first_name` varchar(50) NOT NULL DEFAULT '0',
  `banned` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `fb_user_id` (`fb_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf16;

-- Data exporting was unselected.
-- Dumping structure for table mhmapspotter.maps
CREATE TABLE IF NOT EXISTS `maps` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(75) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=128 DEFAULT CHARSET=utf16;

-- Data exporting was unselected.
-- Dumping structure for table mhmapspotter.requests
CREATE TABLE IF NOT EXISTS `requests` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `man_expired` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `dusted` tinyint(1) unsigned DEFAULT NULL,
  `mouse_id` smallint(5) unsigned DEFAULT NULL,
  `map_id` smallint(5) unsigned DEFAULT NULL,
  `reward_count` smallint(5) unsigned DEFAULT NULL,
  `type_id` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `fb_user_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=utf16;

-- Data exporting was unselected.
-- Dumping structure for table mhmapspotter.requests_fb_posts
CREATE TABLE IF NOT EXISTS `requests_fb_posts` (
  `request_id` int(10) unsigned NOT NULL,
  `fb_post_id` bigint(20) unsigned NOT NULL,
  `fb_group_id` tinyint(3) unsigned NOT NULL,
  UNIQUE KEY `fb_post_id` (`fb_post_id`),
  KEY `fb_group_id` (`fb_group_id`),
  KEY `request_id` (`request_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf16 ROW_FORMAT=DYNAMIC;

-- Data exporting was unselected.
-- Dumping structure for table mhmapspotter.request_types
CREATE TABLE IF NOT EXISTS `request_types` (
  `id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf16;

-- Data exporting was unselected.
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
