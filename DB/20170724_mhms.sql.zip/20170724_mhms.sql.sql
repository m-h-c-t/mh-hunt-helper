-- --------------------------------------------------------
-- Host:                         localhost
-- Server version:               5.7.19-0ubuntu0.16.04.1-log - (Ubuntu)
-- Server OS:                    Linux
-- HeidiSQL Version:             9.4.0.5174
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


-- Dumping database structure for mhmapspotter
CREATE DATABASE IF NOT EXISTS `mhmapspotter` /*!40100 DEFAULT CHARACTER SET utf16 */;
USE `mhmapspotter`;

-- Dumping structure for event mhmapspotter.40 update map_mice_aggr
DELIMITER //
CREATE DEFINER=`root`@`localhost` EVENT `40 update map_mice_aggr` ON SCHEDULE EVERY 1 HOUR STARTS '2017-07-17 11:40:30' ON COMPLETION PRESERVE ENABLE DO BEGIN

START TRANSACTION;

TRUNCATE mhmapspotter.map_mice_aggr;

INSERT INTO mhmapspotter.map_mice_aggr (mouse_id, map_type_id, seen_maps)
SELECT mm.mouse_id, mr.map_type_id, COUNT(DISTINCT mr.map_id)
FROM mhmapspotter.map_records mr
INNER JOIN mhmapspotter.map_mice mm ON mr.map_id = mm.map_id
GROUP BY mr.map_type_id, mm.mouse_id;

UPDATE mhmapspotter.map_mice_aggr mma
INNER JOIN (
	SELECT mr.map_type_id, COUNT(DISTINCT mr.map_id) AS total_maps
	FROM mhmapspotter.map_records mr
	GROUP BY mr.map_type_id) AS a ON mma.map_type_id = a.map_type_id
SET mma.total_maps = a.total_maps;

UPDATE mhmapspotter.map_mice_aggr mma SET mma.rate = ROUND(mma.seen_maps/mma.total_maps*10000);

COMMIT;

END//
DELIMITER ;

-- Dumping structure for table mhmapspotter.fb_groups
CREATE TABLE IF NOT EXISTS `fb_groups` (
  `id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `fb_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `fb_id` (`fb_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf16;

-- Data exporting was unselected.
-- Dumping structure for table mhmapspotter.fb_users
CREATE TABLE IF NOT EXISTS `fb_users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `fb_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `first_name` varchar(50) NOT NULL DEFAULT '0',
  `banned` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `fb_user_id` (`fb_id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf16;

-- Data exporting was unselected.
-- Dumping structure for table mhmapspotter.maps
CREATE TABLE IF NOT EXISTS `maps` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(75) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=81 DEFAULT CHARSET=utf16;

-- Data exporting was unselected.
-- Dumping structure for table mhmapspotter.map_mice
CREATE TABLE IF NOT EXISTS `map_mice` (
  `map_id` int(10) unsigned NOT NULL,
  `mouse_id` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`map_id`,`mouse_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf16 ROW_FORMAT=DYNAMIC;

-- Data exporting was unselected.
-- Dumping structure for table mhmapspotter.map_mice_aggr
CREATE TABLE IF NOT EXISTS `map_mice_aggr` (
  `map_type_id` int(10) unsigned NOT NULL,
  `mouse_id` int(10) unsigned NOT NULL,
  `seen_maps` int(10) unsigned NOT NULL DEFAULT '0',
  `total_maps` int(10) unsigned NOT NULL DEFAULT '0',
  `rate` smallint(5) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`map_type_id`,`mouse_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf16;

-- Data exporting was unselected.
-- Dumping structure for table mhmapspotter.map_records
CREATE TABLE IF NOT EXISTS `map_records` (
  `map_id` int(10) unsigned NOT NULL,
  `map_type_id` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`map_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf16;

-- Data exporting was unselected.
-- Dumping structure for table mhmapspotter.requests
CREATE TABLE IF NOT EXISTS `requests` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `man_expired` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `dusted` tinyint(1) unsigned DEFAULT NULL,
  `mouse_id` smallint(5) unsigned DEFAULT NULL,
  `map_id` smallint(5) unsigned DEFAULT NULL,
  `reward_count` smallint(5) unsigned DEFAULT NULL,
  `type_id` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `fb_user_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=108 DEFAULT CHARSET=utf16;

-- Data exporting was unselected.
-- Dumping structure for table mhmapspotter.requests_fb_posts
CREATE TABLE IF NOT EXISTS `requests_fb_posts` (
  `request_id` int(10) unsigned NOT NULL,
  `fb_post_id` bigint(20) unsigned NOT NULL,
  `fb_group_id` tinyint(3) unsigned NOT NULL,
  UNIQUE KEY `fb_post_id` (`fb_post_id`),
  KEY `fb_group_id` (`fb_group_id`),
  KEY `request_id` (`request_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf16 ROW_FORMAT=DYNAMIC;

-- Data exporting was unselected.
-- Dumping structure for table mhmapspotter.request_types
CREATE TABLE IF NOT EXISTS `request_types` (
  `id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf16;

-- Data exporting was unselected.
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
